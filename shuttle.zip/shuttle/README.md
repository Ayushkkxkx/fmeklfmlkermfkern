# Safar
Cab Management

Step to Execute:
1)	Download the zip file.
2)	Extract it and store it in the location path: C:\xampp\htdocs
3)	Rename the folder named ‘Safar-master’ as safar
4)	Open Xampp control panel, and select the start option for Apache and MySql
5)	After few seconds, select the admin option on Apache and mysql.
6)	Create a new database named safar
7)	Import the files customer.sql and ride_details.sql inside this database
8)	In the admin site, type localhost/safar to view all the files.
9)	Click on homepage_safar.php. And them visit the complete site through here.

Pre-requisite: 
1)	Xampp software.
2)	A good editing software such as sublime text, notepad++.
