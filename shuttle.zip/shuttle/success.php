<html>
<head>
<title>Success</title>
</head>
<body bgcolor="powderblue">
	<h1 position='center'>Payment Successful!</h1>
</body>
</html>
<?php
/*include("user_booking_detail.php");
mysql_connect("localhost","root","") or die("Problem with connection...");
mysql_select_db("safar");
if($tmp_slot<41)
{
$amount=50;
}
else
{
$amount=25;
}
$num=rand(98525,99999);
mysql_query("INSERT INTO
booking(transaction_id,email,venue,day,slot,payment )
VALUES($num,'$tmp_username','$tmp_building','$tmp_day','$tmp_slot',$amount)
");
echo "<br />";
echo "<br />";
echo "<br />";
echo "<br />";
echo "<br />";
echo "<br />";
echo "<br />";
echo "<br />";
echo "<center><h1>Payment received successfully</h1></center>";
echo "<br />";
echo "<br />";
echo "<br />";
?>
<h2><center> Venue: <?php echo $tmp_building; ?>
<center> Day: <?php echo $tmp_day; ?>
<center> Slot: <?php echo $tmp_slot; ?>
 <center> Price: <?php echo $amount; ?></h2>
</body>
</html>
*/