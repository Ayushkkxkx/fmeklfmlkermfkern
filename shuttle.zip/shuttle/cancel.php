<html>
<head>
<title> Cancel Transaction</title>
<style type="text/css">
h2 {
color: pink;
background-color: white;
 border-bottom: 2px solid white;
 background-color: black;
}
body {background-color:#d2b953;
color: white;
font-size:20px;
backgroundimage:url(https://sites.google.com/site/mrdorn/_/rsrc/1426045277141/video/p
ictures-for-website/3D-Background-High-Definition-HD.jpg);
background-repeat:no-repeat;background-position:top left;backgroundattachment:fixed; text-align:center; color:white;
}
</style>
</head>
<body>
<?php
echo "<br />";
echo "<br />";
echo "<br />";
echo "<br />";
echo "<br />";
echo "<br />";
echo "<br />";
echo "<br />";
echo "<center><h1>OOPS! There was some problem. The Transaction has been
cancelled</h1></center>";
echo "<br />";
echo "<br />";
echo "<br />";
?>
